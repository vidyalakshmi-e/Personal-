"""Device: a plain dataclass describing any piece of smart-home hardware."""

from dataclasses import dataclass


@dataclass
class Device:
    """Basic data about a device.

    Attributes:
        name: Human readable device name, e.g. "Living Room Lamp".
        device_type: Category string, e.g. "light", "thermostat", "lock".
        power_watts: Rated power draw in watts.
    """

    name: str
    device_type: str
    power_watts: float

    def __post_init__(self) -> None:
        """No-op here. Defined so the generated __init__ always calls
        self.__post_init__(), which lets subclasses (SmartDevice and
        friends) hook in extra setup via normal method-resolution-order
        polymorphism."""
        pass

    def __repr__(self) -> str:
        # Magic method requirement: Device.__repr__()
        return f"<Device name={self.name!r} type={self.device_type!r} power={self.power_watts}W>"
