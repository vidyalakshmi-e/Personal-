"""SmartHome: HOLDS a list of rooms (composition, level 2 -
SmartHome -> Room -> Device)."""

from typing import Iterator, List

from .room import Room


class SmartHome:
    def __init__(self, name: str):
        self.name = name
        self.rooms: List[Room] = []

    def add_room(self, room: Room) -> None:
        self.rooms.append(room)

    def total_power_watts(self) -> float:
        return sum(room.total_power_watts() for room in self.rooms)

    def __getitem__(self, room_name: str) -> Room:
        # Magic method requirement: SmartHome.__getitem__(room_name)
        for room in self.rooms:
            if room.name == room_name:
                return room
        raise KeyError(f"No room named {room_name!r}")

    def __len__(self) -> int:
        return len(self.rooms)

    def __iter__(self) -> Iterator[Room]:
        return iter(self.rooms)

    def __repr__(self) -> str:
        return f"<SmartHome name={self.name!r} rooms={len(self)}>"
