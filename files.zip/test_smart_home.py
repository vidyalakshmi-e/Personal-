import pytest

from smart_home import (
    Device,
    Room,
    SmartHome,
    SmartLight,
    SmartLock,
    SmartThermostat,
)
from smart_home.smart_device import SmartDevice


def make_light():
    return SmartLight(name="Lamp", device_type="light", power_watts=10)


def make_thermostat():
    return SmartThermostat(name="Thermo", device_type="thermostat", power_watts=5)


def make_lock():
    return SmartLock(name="Lock", device_type="lock", power_watts=2)


class TestDevice:
    def test_dataclass_fields(self):
        d = Device(name="X", device_type="light", power_watts=7.5)
        assert d.name == "X"
        assert d.device_type == "light"
        assert d.power_watts == 7.5

    def test_repr(self):
        d = Device(name="X", device_type="light", power_watts=7.5)
        assert "X" in repr(d)
        assert "light" in repr(d)


class TestAbstractBase:
    def test_cannot_instantiate_smart_device_directly(self):
        with pytest.raises(TypeError):
            SmartDevice(name="X", device_type="generic", power_watts=1)

    def test_subclasses_behave_differently(self):
        light = make_light()
        lock = make_lock()
        assert "light" in light.turn_on().lower()
        assert "lock" in lock.turn_on().lower()
        assert light.is_on is True
        assert lock.locked is True


class TestThermostatProperty:
    def test_default_temp_within_range(self):
        t = make_thermostat()
        assert SmartThermostat.MIN_TEMP <= t.target_temp <= SmartThermostat.MAX_TEMP

    @pytest.mark.parametrize("value", [16, 20, 30])
    def test_accepts_boundary_and_inrange_values(self, value):
        t = make_thermostat()
        t.target_temp = value
        assert t.target_temp == value

    @pytest.mark.parametrize("value", [15, 31, -5, 100])
    def test_rejects_out_of_range_values(self, value):
        t = make_thermostat()
        with pytest.raises(ValueError):
            t.target_temp = value


class TestRoomComposition:
    def test_len_returns_device_count(self):
        room = Room("Bedroom")
        assert len(room) == 0
        room.add_device(make_light())
        room.add_device(make_lock())
        assert len(room) == 2

    def test_iterates_devices(self):
        room = Room("Bedroom")
        room.add_device(make_light())
        assert list(room)[0].name == "Lamp"


class TestSmartHomeComposition:
    def test_getitem_looks_up_room_by_name(self):
        home = SmartHome("Casa")
        room = Room("Kitchen")
        home.add_room(room)
        assert home["Kitchen"] is room

    def test_getitem_raises_for_missing_room(self):
        home = SmartHome("Casa")
        with pytest.raises(KeyError):
            home["Nonexistent"]

    def test_two_levels_deep_composition(self):
        home = SmartHome("Casa")
        room = Room("Kitchen")
        light = make_light()
        room.add_device(light)
        home.add_room(room)
        assert home["Kitchen"].devices[0] is light

    def test_total_power_only_counts_devices_that_are_on(self):
        home = SmartHome("Casa")
        room = Room("Kitchen")
        light = make_light()
        lock = make_lock()
        room.add_device(light)
        room.add_device(lock)
        home.add_room(room)

        assert home.total_power_watts() == 0
        light.turn_on()
        assert home.total_power_watts() == light.power_watts
