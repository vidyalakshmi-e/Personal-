"""Room: HOLDS a list of devices (composition, level 1)."""

from typing import Iterator, List

from .smart_device import SmartDevice


class Room:
    def __init__(self, name: str):
        self.name = name
        self.devices: List[SmartDevice] = []

    def add_device(self, device: SmartDevice) -> None:
        self.devices.append(device)

    def total_power_watts(self) -> float:
        """Sum of power_watts for devices currently turned on."""
        return sum(d.power_watts for d in self.devices if d.is_on)

    def __len__(self) -> int:
        # Magic method requirement: Room.__len__() returns device count
        return len(self.devices)

    def __iter__(self) -> Iterator[SmartDevice]:
        return iter(self.devices)

    def __repr__(self) -> str:
        return f"<Room name={self.name!r} devices={len(self)}>"
