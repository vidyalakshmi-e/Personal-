# Smart Home Device Controller (Option 4)

A small OOP exercise built with Python's standard library only.

## Project structure

```
smart_home_controller/
├── smart_home/
│   ├── __init__.py       # public API
│   ├── device.py         # Device dataclass
│   ├── smart_device.py   # SmartDevice ABC + SmartLight / SmartThermostat / SmartLock
│   ├── room.py           # Room (holds a list of devices)
│   └── home.py           # SmartHome (holds a list of rooms)
├── tests/
│   ├── __init__.py
│   └── test_smart_home.py
├── main.py                # runnable demo
└── README.md
```

## What each requirement maps to

| Requirement | Where |
|---|---|
| Dataclass `Device` (`name`, `device_type`, `power_watts`) | `smart_home/device.py` |
| Property: `target_temp` rejecting values outside 16–30°C | `TemperatureControlMixin` in `smart_home/smart_device.py`, used by `SmartThermostat` |
| ABC `SmartDevice` with abstract `turn_on()` / `turn_off()` | `smart_home/smart_device.py` |
| Subclasses `SmartLight`, `SmartThermostat`, `SmartLock`, each behaving differently | `smart_home/smart_device.py` |
| Composition: `Room` HOLDS a list of `Device`s | `smart_home/room.py` |
| Composition: `SmartHome` HOLDS a list of `Room`s (2 levels deep) | `smart_home/home.py` |
| `Room.__len__()` → device count | `smart_home/room.py` |
| `SmartHome.__getitem__(room_name)` → look up a room by name | `smart_home/home.py` |
| `Device.__repr__()` | `smart_home/device.py` (and overridden in `SmartDevice` for on/off state) |

## Run the demo

```bash
cd smart_home_controller
python3 main.py
```

## Run the tests

```bash
cd smart_home_controller
pip install pytest --break-system-packages   # if not already installed
pytest -v
```
