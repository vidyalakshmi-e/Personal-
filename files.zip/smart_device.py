"""SmartDevice: the abstract base class for every controllable device,
plus its concrete subclasses (SmartLight, SmartThermostat, SmartLock).
"""

from abc import ABC, abstractmethod

from .device import Device


class SmartDevice(Device, ABC):
    """Abstract base for anything that can be turned on/off.

    Inherits the plain data fields (name, device_type, power_watts) from
    Device, and adds the behavioural contract every smart device must
    implement.
    """

    def __post_init__(self) -> None:
        self.is_on: bool = False

    @abstractmethod
    def turn_on(self) -> str:
        """Turn the device on. Returns a status message."""
        raise NotImplementedError

    @abstractmethod
    def turn_off(self) -> str:
        """Turn the device off. Returns a status message."""
        raise NotImplementedError

    def __repr__(self) -> str:
        state = "ON" if getattr(self, "is_on", False) else "OFF"
        return f"<{self.__class__.__name__} name={self.name!r} state={state}>"


class SmartLight(SmartDevice):
    """A dimmable smart light. brightness ranges 0-100."""

    def __post_init__(self) -> None:
        super().__post_init__()
        self.brightness: int = 0

    def turn_on(self) -> str:
        self.is_on = True
        self.brightness = self.brightness or 100
        return f"{self.name} light is ON at {self.brightness}% brightness"

    def turn_off(self) -> str:
        self.is_on = False
        self.brightness = 0
        return f"{self.name} light is OFF"


class TemperatureControlMixin:
    """Adds a validated target_temp property.

    Rejects any value outside the 16-30 degrees Celsius range, per the
    "Property" requirement for a Thermostat-style class.
    """

    MIN_TEMP = 16
    MAX_TEMP = 30

    @property
    def target_temp(self) -> float:
        return self._target_temp

    @target_temp.setter
    def target_temp(self, value: float) -> None:
        if not (self.MIN_TEMP <= value <= self.MAX_TEMP):
            raise ValueError(
                f"target_temp must be between {self.MIN_TEMP} and "
                f"{self.MAX_TEMP}\u00b0C, got {value}"
            )
        self._target_temp = value


class SmartThermostat(SmartDevice, TemperatureControlMixin):
    """A thermostat with a validated target_temp property (16-30°C)."""

    DEFAULT_TEMP = 20

    def __post_init__(self) -> None:
        super().__post_init__()
        self.target_temp = self.DEFAULT_TEMP

    def turn_on(self) -> str:
        self.is_on = True
        return f"{self.name} thermostat is ON, targeting {self.target_temp}\u00b0C"

    def turn_off(self) -> str:
        self.is_on = False
        return f"{self.name} thermostat is OFF"


class SmartLock(SmartDevice):
    """A smart lock. turn_on() locks it, turn_off() unlocks it."""

    def __post_init__(self) -> None:
        super().__post_init__()
        self.locked: bool = False

    def turn_on(self) -> str:
        self.is_on = True
        self.locked = True
        return f"{self.name} lock is now LOCKED"

    def turn_off(self) -> str:
        self.is_on = False
        self.locked = False
        return f"{self.name} lock is now UNLOCKED"
