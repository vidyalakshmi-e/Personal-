"""Demo: exercises every requirement from Option 4 - Smart Home Device Controller."""

from smart_home import Room, SmartHome, SmartLight, SmartLock, SmartThermostat


def main() -> None:
    # --- Build devices ---------------------------------------------------
    lamp = SmartLight(name="Floor Lamp", device_type="light", power_watts=9)
    ceiling_light = SmartLight(name="Ceiling Light", device_type="light", power_watts=12)
    thermostat = SmartThermostat(name="Hallway Thermostat", device_type="thermostat", power_watts=5)
    front_lock = SmartLock(name="Front Door Lock", device_type="lock", power_watts=2)

    # --- Property validation on the thermostat ----------------------------
    print(thermostat.turn_on())
    thermostat.target_temp = 22
    print(f"Target temp set to {thermostat.target_temp}\u00b0C")
    try:
        thermostat.target_temp = 40  # outside 16-30 range -> rejected
    except ValueError as exc:
        print(f"Rejected bad temp: {exc}")

    # --- Turn devices on/off (each subclass behaves differently) ---------
    print(lamp.turn_on())
    print(ceiling_light.turn_on())
    print(front_lock.turn_on())  # "locks" the door

    # --- Composition: Room holds Devices ----------------------------------
    living_room = Room("Living Room")
    living_room.add_device(lamp)
    living_room.add_device(ceiling_light)

    hallway = Room("Hallway")
    hallway.add_device(thermostat)
    hallway.add_device(front_lock)

    print(f"\nDevices in {living_room.name}: {len(living_room)}")  # __len__
    for device in living_room:
        print(" ", repr(device))

    # --- Composition: SmartHome holds Rooms (2 levels deep) ---------------
    home = SmartHome("My House")
    home.add_room(living_room)
    home.add_room(hallway)

    print(f"\n{home!r}")
    found = home["Hallway"]  # __getitem__
    print(f"Looked up room by name -> {found!r}")

    print(f"\nTotal power draw across the whole home: {home.total_power_watts()}W")

    print("\nDevice reprs:")
    for room in home:
        for device in room:
            print(" ", repr(device))


if __name__ == "__main__":
    main()
